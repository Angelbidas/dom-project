<?php
  include("dbconnection.php");
  $id =$_GET['id'];
  
  $query = "DELETE FROM questions WHERE id=".$id;
  //echo $query;
  
  $r = mysqli_query($conn, $query);
  
  if($r){
	 header('location:messages.php');
  }else{
	  echo "Something went wrong!";
  }

?>
<?php
 session_start();
?>
<html>
<head>
<title>login as worker</title>
<link rel="stylesheet" type="text/css"href="style.css">
<style>
.topnav{

background-color:#333;
height:80px;
}
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align:right;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
.dropbtn{
display:inline-block;
color:white;
text-align:right;
padding:14px 16px;
text-decoration:none;
}
.dropbtn {
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* The container needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}


.topnav a:hover, .dropdown:hover .dropbtn{
background-color:skyblue;
}
ul {
 list-style-type: none;
 margin: 0;
 padding: 0;
 overflow: hidden;
 background-color: #333333;
}
li a {
 display: block;
 color: white;
 text-align: center;
 padding: 16px;
 text-decoration: none;
}
.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
.main {
  padding: 20px;
  margin-top: 20px;
  height: 20px; 
}
.topnav-right {
  float: right;
}

img:hover {
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
}
* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); 
  background: rgba(0, 0, 0, 0.5); 
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
.fa {
  padding: 30px;
  font-size: 30px;
  width: 30px;
  text-align: left;
  text-decoration: none;
  margin: 2px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.4;
}

body{
margin:0;
padding:0;
 background-image:url(dom-photos/dom.jpg);
 background-size:cover;
 background-position:center;
 font-family:sans-serif;
 }
 .loginbox{
 width:320px;
 height:420px;
 background:#000;
 color:#fff;
 top:50%;
 left:50%;
 position:absolute;
 transform:translate(-50%,-50%);
 box-sizing:border-box;
 padding:70px 30px
 }
 .avatar{
 width:100px;
 height:100px;
 border-radius:50%;
 position:absolute;
 top:-50px;
 left:calc(50% - 50px);
 }
 h1{
 margin:0;
 padding:0 0 20px;
 text-align:center;
 font-size:22px;
 }
 .loginbox p{
 margin:0;
 padding:0;
 font-weight:bold;
 }
 .loginbox input{
 width:100%;
 margin-bottom:30px;
 }
 loginbox input[type="text"],input[type="password"]
 {
 border:none;
 border-bottom:1px solid #fff;
 outline:none;
 height:20px;
 }
 .loginbox input[type="submit"]
 {
 border:none;
 outline:none;
 height:50px;
 background:#fb2525;
 color:#fff;
 font-size:28px;
 border-radius:40px;
 }
 .loginbox input[type="submit"]:hover
 {
 cursor:pointer;
 background:#ffc107;
 color:#000;
 }
 .loginbox a{
 text-decoration:none;
 font-size:12px;
 line-height:20px;
 color:darkgrey;
 }
 

 </style>
</head>
<body>
<div class="topnav">

<a href="index.php">HOME</a>
 
<a href="contactus.php">CONTACT US</a>
  
<a href="aboutus.php">ABOUT US</a>

  <div class="dropdown">
 <a href="#"class="dropbtn">LOGIN</a>
 <div class="dropdown-content">
  <a href="assearcher.php">AS SEARCHER</a>
  <a href="as worker.php">AS WORKER</a>
  <a href="as admin.php">AS ADMIN</a>
   </div>
</div>
</div>
<br/>

<div class="loginbox">
<img src="dom-photos/ava.png"class="avatar">
<h1>LOGIN AS WORKER</h1>
  <form method="POST" action="login-worker.php">
   <p>Email</p>
   <input type="text" name="email" placeholder="enter username">
  <p>Password</p>
  <input type="Password" name="pwd" placeholder="enter password"><br/>
  <input type="submit" name="submit" value="login">
</form>
</body></html>
  <!-- <a href="workersignup.html"><input type="button"value="login"></a></p> -->
  <p><a href="workerregister.php">signup if you do not have account</a></p>
</form>

</body></html>
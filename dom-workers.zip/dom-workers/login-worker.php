<?php
session_start();
include_once 'dbconnection.php';
$email=$_POST['email'];
$pwd=$_POST['pwd'];

if(empty($email) || empty($pwd))
{
    header("Location:as worker.php?error=empty");
    exit();
}
else
{
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))
    {
        header("Location:as worker.php?error=email");
        exit();
    }
    else
    {
       $sql="SELECT* FROM workers WHERE email='$email';";
       $result=mysqli_query($conn,$sql);
       if(mysqli_num_rows($result)<1)
       {
          header("Location:as worker.php?error=notFound");
          exit();
       }
       else
       {
           if($row=mysqli_fetch_assoc($result))
           {
               if($row['pwd']==$pwd)
               {

                $_SESSION['fname']=$row['fname'];
                header("Location:searcheravailable.php?error=success");
                exit();
               }
           }
       }
    }
}
?>
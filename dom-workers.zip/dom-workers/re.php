<?php 
include('dbconnection.php');
	$rid = '';


      $calc_days = abs(strtotime($_GET['out']) - strtotime($_GET['in'])) ;
 $calc_days =floor($calc_days / (60*60*24)  );
?>
<style>
	.main-block
{
padding-top:10px;
padding-bottom:10px;
}
.formcontainer {
      max-width: 300px; 
      max-height: max-content;
      border:1px solid black;
      background-color:white;
      float:left;
      }
      input{
      width: 90%;
      padding: 10px 5px;
      border-bottom: 1px solid black;
      border-radius: 10px 10px 10px 10px;
      outline:none;
      margin: 10px 10px 10px 10px;
      }
      .formcontainer button {
      background-color: #034e94;
      color: white;
      padding: 10px 0;
      margin: 10px 0;
      border: none;
      cursor:pointer;
      width: 40%;
      padding:auto;
      }
      button:hover {
      opacity: 0.9;
      }
label
{
margin-left:40px;
font-size:16px;
font-weight:bold;
}
</style>
<div class="formcontainer">
	
	<form action="index.php?page=request">
	<?php 
include('dbconnection.php');
	$rid = '';

 
$calc_days = abs(strtotime($_GET['out']) - strtotime($_GET['in'])) ;
 $calc_days =floor($calc_days / (60*60*24)  );
?>
<div class="formcontainer">
	
	<form action="request.php">
		<input type="hidden" name="cid" value="<?php echo isset($_GET['cid']) ? $_GET['cid']: '' ?>">
		<input type="hidden" name="rid" value="<?php echo isset($_GET['rid']) ? $_GET['rid']: '' ?>">
			<label for="name">Name</label>
			<input type="text" name="name"  value="<?php echo isset($meta['name']) ? $meta['name']: '' ?>" required>

			<label for="contact">phone </label>
			<input type="text" name="tel"  value="<?php echo isset($meta['contact_no']) ? $meta['contact_no']: '' ?>" required>

                  <label for="contact">email </label>
			<input type="text" name="id"  value="<?php echo isset($meta['contact_no']) ? $meta['contact_no']: '' ?>" required>

			<label for="date_in">Check-in Date</label>
			<input type="date" name="date_in" value="<?php echo isset($_GET['in']) ? date("Y-m-d",strtotime($_GET['in'])): date("Y-m-d") ?>" required >

			<label for="date_in_time">Check-in Time</label>
			<input type="time" name="date_in_time"  value="<?php echo isset($_GET['date_in']) ? date("H:i",strtotime($_GET['date_in'])): date("H:i") ?>" required>

			<label for="days">Days of Stay</label>
			<input type="number" min ="1" name="days" value="<?php echo isset($_GET['in']) ? $calc_days: 1 ?>" required >

	</form>
</div>
<html>
<head>
<title>REGISTRATION</title>
<style>
.topnav{

background-color:#333;
height:80px;
}
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align:right;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
.dropbtn{
display:inline-block;
color:white;
text-align:right;
padding:14px 16px;
text-decoration:none;
}
.dropbtn {
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* The container needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}


.topnav a:hover, .dropdown:hover .dropbtn{
background-color:skyblue;
}
ul {
 list-style-type: none;
 margin: 0;
 padding: 0;
 overflow: hidden;
 background-color: #333333;
}
li a {
 display: block;
 color: white;
 text-align: center;
 padding: 16px;
 text-decoration: none;
}
.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
.main {
  padding: 30px;
  margin-top: 30px;
  height: 70px; 
}
.topnav-right {
  float: right;
}

img:hover {
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
}
* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); 
  background: rgba(0, 0, 0, 0.5); 
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
.fa {
  padding: 30px;
  font-size: 30px;
  width: 30px;
  text-align: left;
  text-decoration: none;
  margin: 2px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.4;
}
.body{
  background-color:rgb(122, 95, 95)
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap');

body{
line-height:1.5;
font-family: 'Poppins', sans-serif;
}
.
{
margin:0;
padding:0;
box-sizing:border-box;
}
.column{
float:left;
width:33.33%;
}
.row:after
{
content:"";
display:table;
clear:both;
}
.footer ul{
style-type:none;
display:flex;
flex-direction:column;
}
.footer ul li{
text-align:left;
}
.footer{
background-color:#24262b;
padding:70px 0;
}
.footer-col{
width:25%;
padding:0 15px;
}
.footer-col h4{
footer-size:18px;
color:#ffffff;
text-transform:capitalize;
margin-bottom:35px;
font-weight:500;
position:relative;

}
.footer-col h4::before{
content:'';
position:absolute;
left:0;
bottom:-10px;
background-color:#e91e63;
height:2px;
box-sizing:border-box;
width:50px;
}
.column ul li:not(:last-child){
margin-bottom:10px;
}
.footer a{
font-size:16px;
text-transform:capitalize;
color:#ffffff;
text-decoration:none;
font-weight:300;
color:#bbbbbb;
transition:all 0.3s ease;
}
.footer a:hover{
color:#ffffff;
padding-left:8px;
}
.footer .social-links a{
height:40px;
width:40px;
background-color:rgba(255,255,255,0.2);
text-align:center;
line-height:40%
border-radius:50%
color:#ffffff;
transition:all 0.5s ease;
margin-right: 20px;
}
.column .social-links a:hover{
color:#24262b;
background-color:#ffffff;
}
input[type="submit"]{
  width: 130px;
  height: 30px;
  background-color: rgba(153, 49, 49, 0.5);
  border-radius: 10px;
  color: white;
  border: none;
}
input[type="submit"]:hover{
  background-color: rgba(233, 8, 8, 0.8);
  cursor: pointer;
}
@media(ma-width:767px)
{
.footer-col{
width:50%;
margin-bottom:30px;
}
}
h4{ text-align:center;
font-size:24px;
color:white;
font-weight:bold;
font-family:serif;

}
.footer-text p
{
  color: rgba(255, 255, 255, 0.438);
  
}
row{
  
}
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</style>
</head><body>
<div class="topnav">
<div class="logo">
  <a class="navbar-brand" href="https://www.helperchoice.com"><img src="dom-photos/logo1.PNG"></a></div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="index.php">HOME</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="contactus.php">CONTACT US</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="aboutus.php">ABOUT US</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 
  <div class="dropdown">
 <a href="#"class="dropbtn">LOGIN</a>
 <div class="dropdown-content">
  <a href="assearcher.php">AS SEARCHER</a>
  <a href="as worker.php">AS WORKER</a>
   <a href="as admin.php">AS ADMIN</a>
   </div>
</div>
</div>
<br/>

<h2 align="center">REQUEST FORM</h2>

<div class="row">
<div class="column">


</div>
  <div class="column">

<form align="center" method="POST" action="reg-request.php">
 
 
  <label for="fname"> FIRSTNAME:</label>
  <input type="text" id="fname" name="fname"><br/><br/>
  
   <label for="lname">LASTNAME:</label>
  <input type="text" id="lname" name="lname"><br/><br/>
  
  <label for="id">E-mail:</label>
  <input type="text" id="id" name="id"><br/><br/>
 
   <label for="tel">PHONE:</label>
  <input type="text" id="tel" name="tel"><br/><br/>
 

   <input type ="submit" name="submit" value="SUBMIT"></p>
</form>
</div>

</div>
<div class="main">
</div>
<div class="footer">
<div class="row">
<div class="column">
<ul>
<li><h4>ABOUT </h4></li>
<li><a href="aboutus.php">aboutus</a></li>
<li><a href="contactus.php">history</a></li>
<li><a href="workerregister.php">resources </a></li>
<li><a href="requirement.php">requirement</a></li>
</ul>
</div>
<div class="column">
<ul>
<li><h4>GET HELP</h4></li>
<li><a href="workerregister.php">registration</a></li>
<li><a href="contactus.php">contactus</a></li>
<li><a href="ssignup.php">account</a></li>
<li><a href="aboutus.php">aboutus</a></li>
</ul>
</div>
<div class="column">
<ul>
<li><h4>GET INVOLVED</h4></li>
<li><a href="worker signup.php">signup</a></li>
<li><a href="requirement.php">requirement</a></li>
<li><a href="assearcher.php">search</a></li>
<li><a href="as worker.php">worker</a></li>
</ul>
</div>
</div><center>
<div class="social-links">
<a href="https://twitter.com/domesticworkers"><i class="fab fa-twitter"></i></a>
<a href="https://www.facebook.com/nationaldomesticworkersalliance/"><i class="fab fa-facebook-f"></i></a>
<a href="https://www.instagram.com/domesticworkers/"><i class="fab fa-instagram"></i></a>
</div></center>
<div class="footer-text-container">
  <div class="footer-text">

  <p class="small show-for-en">©2021 Copyright National Domestic Workers Alliance, A non-profit organization whose mission is to support domestic workers to live and work with dignity. <a href="/privacy-policy" target="_blank">Privacy Policy</a></p>
  </div>
  </div>

</div>
</footer>
</div>
</div>
</body></html>
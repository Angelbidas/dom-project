<?php
$server="127.0.0.1";
$user="root";
$pass="";
$db="huyecse";
$connection=mysqli_connect($server,$user,$pass,$db);
if(!$connection){
echo"not passing";
}else{
echo"passing";
}
?>


<form action="" method="POST">
<input type text="text"name="name"placeholder="enter the product name">
</br>
<input type text="number"name="price"placeholder="enter the product price">
</br>
<input type text="submit"name="submit" value="save"placeholder="enter the product name">
</br>
<input type text="submit"name="retrieve" value="retrieve"placeholder="enter the product name">
</form>
<?php
if(isset($_post[submit])){
echo $_POST['pname'];
echo $_POST['price'];
$query=INSERT INTO PRODUCT(id,pname,price);
VALUES('',$name,$price);
$r=mysqli_query($connection,$query);
if(!$r){//echo $query;
echo"failed".mysqli_error($connection)
}alse{
    echo"product saved";
}
}else{
    $rqu="SELECT*FROM product";
    $result=mysqli_query($connection,$rqu);
?php>
<table border="1">
    <tr>
        <th>ID</th>
<th>product name</th>
<th>product price</th>
</tr>
?php>
    while($r=mysqli_fetch_array($result)){
        echo <tr><td>$r['id']."</td><td>".$r['pname']."</td><td>".$r['price']."</td>"
    }
}
echo"submit buton is pressed";
}else{
echo "retrieve button is pressed";
}
?>
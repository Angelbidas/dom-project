<?php
  include("dbconnection.php");
  
?>
 <link rel="stylesheet" type="text/css" href="pro.css">
 <form method="POST" action="registration-searcher.php">
<h2 align="center">SEARCHER SIGNUP</h2>
<label for="fname">USERNAME:</label>
<input type="text" id="uname" name="uname"><br/><br/>
<label for="fname">FIRST NAME:</label>
<input type="text" id="fname" name="fname"><br/><br/>
<label for="fname">LAST NAME:</label>
<input type="text" id="fname" name="lname"><br/><br/>
 <label for="email"> E-MAIL ID:</label>
<input type="text" id="email" name="email"><br/><br/>
 <label for="password">PASSWORD:</label>
<input type="password" id="password" name="password"><br/><br/> 
 <label for="password">CONFIRM PASSWORD:</label>
<input type="password" id="password" name="password"><br/><br/> 
<label for="fname">DISTRICT:</label>
<input type="text" id="places" name="places"><br/><br/>
<label for="fname">PROVINCE:</label>
<input type="text" id="places" name="places"><br/><br/>
<label for="fname">SECTOR</label>
<input type="text" id="places" name="places"><br/><br/>
<label for="fname">CELL:</label>
<input type="text" id="places" name="places"><br/><br/>

<input type="submit" name="submit" value="SIGN UP" color="green"></a></p>
</form>
<?php
   if(isset($_POST["submit"])){
	$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$pwd=$_POST['password'];
$district=$_POST['places'];
$province=$_POST['places'];
$sector=$_POST['places'];
$cell=$_POST['places'];
		
		$query= "INSERT INTO productivity (fname,lname,username,email,pwd,district,province,sector,cell)
		VALUES ('$fname','$lname','$uname','$email','$pwd','$district','$province','$sector','$cell');";
		
		$r = mysqli_query($conn, $query); 
	    if(!$r){
			echo "Failed ".mysqli_error($conn);
		}else{
			echo " saved";
		}
   }
   if(isset($_POST["retrieve"]))
   {
	   
	   $rqu = "SELECT * FROM researcher";
	   $result = mysqli_query($conn, $rqu);
	   ?>
	   <table border="1">
	     <tr>
		 <th>ID</th>
    <th>firstname</th>
    <th>lastname</th> 
    <th>username</th>
    <th>email</th>
    <th>pwd</th>
    <th>province</th>
    <th>district</th>
    <th>sector</th>
    <th>cell</th>
			<th colspan="3">action </th>
		</tr> 
		<?php
		$sql = "SELECT * FROM researcher";
		$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

  while($row = mysqli_fetch_assoc($result)) {
    echo "<tr><td>" . $row["fname"]. " </td>
	<td> " . $row["lname"]. " </td>
	<td>" . $row["username"]. " </td>
	<td> " . $row["email"]. " </td>
	<td>" . $row["pwd"]. " </td>
	<td>" . $row["district"]. "</td>
	<td>" . $row["province"]. "</td>
	<td>" . $row["sector"]. "</td>
	<td>" . $row["cell"]. "</td>"
	?>
	<td><a href="seadetail.php?id=<?php echo $row['id'];?>"> More </a></td>
		   <td><a href="productUpdate.php?id=<?php echo $row['id'];?>"> Update</a> </td>
		   <td><a href="productDelete.php?id=<?php echo $row['id'];?>"> Delete </a></td>
		   <?php
	"<br/></tr>";
}
} else {
  echo "0 results";
}



   }
?>
</table>
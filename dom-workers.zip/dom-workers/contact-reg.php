
<head>
<style>

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>
</head>
<body onload="myFunction()" style="margin:0;">


<div style="display:none;" id="myDiv" class="animate-bottom">
  <h2>thanks!</h2>
  <p>your comments has been submitted successfully..</p>
</div>
<?php
header( "refresh:4;url=contactus.php" ); ?>
<script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {;
  document.getElementById("myDiv").style.display = "block";
}
</script>

</body>



<?php

include_once 'dbconnection.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    if(isset($_POST['submit']))
    {
$names=$_POST['names'];
$email=$_POST['email'];
$phone=$_POST['mobile'];
$comments=$_POST['subject'];


if(empty($names) || empty($email) || empty($phone) || empty($comments))
{
   header("Location:contactus.php?error=empty");
   exit();
}
else
{
    if(!preg_match("/^[a-zA-Z ]*$/",$names))
    {
        header("Location:contactus.php?error=invalidNames");
        exit();
    }
    else
    {
           if(!filter_var($email,FILTER_VALIDATE_EMAIL))
           {
            header("Location:contactus.php?error=email");
            exit();
            header( "refresh:1;url=index.php" );
           }
           else
           {
            $sql="INSERT INTO questions(names,email,phone,comments) VALUES('$names','$email','$phone','$comments');";
            mysqli_query($conn,$sql);
            exit();
           }
          
    }}}}
?>
<?php
   include("dbconnection.php");
   $s_id = $_GET['s_id'];
   $query = "SELECT * FROM researcher WHERE s_id =".$s_id;
   
   $result = mysqli_query ($conn, $query);
   if(!$result){
	   echo "Error ".mysqli_error($conn);
   }else{
	   while($row=mysqli_fetch_array($result)){
		    echo "<br/><hr/>";
		   echo " ID: ".$row['s_id']; echo "<br/>";	
            echo "fname: " . $row['fname']; echo "<br/>";
           echo " lname: ". $row['lname']; echo "<br/>";
           echo " email: ". $row['email']; echo "<br/>";
           echo"pwd: " . $row['pwd']; echo "<br/>";
           echo" district: ". $row['district']; echo "<br/>";
           echo" province: ". $row['province']; echo "<br/>";
           echo"sector: " . $row['sector']; echo "<br/>";
           echo" cell: ". $row['cell']; echo "<br/>";
	   }
   }
?>
<?php
  include("dbconnection.php");
  $s_id =$_GET['s_id'];
  
  $query = "DELETE FROM researcher WHERE s_id=".$s_id;
  //echo $query;
  
  $r = mysqli_query($conn, $query);
  
  if($r){
	 header('location:searcherdetail.php');
  }else{
	  echo "Something went wrong!";
  }

?>
<?php
   include("dbconnection.php");
   
   $r = "SELECT * FROM researcher WHERE s_id =".$_GET['s_id'];
   
   $dx = mysqli_query($conn,$r);
   if(!$dx){
	   echo "Failed";
   }
  
   if($d = mysqli_fetch_array($dx)){
	   ?>
	   <form action="" method="post">
		  <input type="hidden" name ="s_id" value="<?php echo $d['s_id'];?>"/>
		  <br/>
        fname: <input type="text" name ="fname" value="<?php echo $d['fname'];?>"/>
		  <br/> 	
		  lname:<input type="text" name ="lname" value="<?php echo $d['lname'];?>"/>
		  <br/> 
		  username:<input type="text" name ="uname" value="<?php echo $d['username'];?>"/>
		  <br/> 
		  email:<input type="text" name ="email" value="<?php echo $d['email'];?>"/>
		  <br/>
			password:<input type="number" name ="password" value="<?php echo $d['pwd'];?>"/>
		   <br/> 
		   district:<input type="text" name ="places" value="<?php echo $d['district'];?>"/>
		  <br/> 
		  province:<input type="text" name ="places" value="<?php echo $d['province'];?>"/>
		  <br/> 
		  district:<input type="text" name ="places" value="<?php echo $d['sector'];?>"/>
		  <br/> 
		  province:<input type="text" name ="places" value="<?php echo $d['cell'];?>"/>
		  <br/> 
			<input type="submit" name ="update" value="Update"/>
			<input type="submit" name ="retrieve" value="Retrieve"/>
		</form> 
	   
	   <?php  
	     if(isset($_POST['update'])){
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$username=$_POST['uname'];
			$email=$_POST['email'];
			$pwd=$_POST['password'];
			$district=$_POST['places'];
			$province=$_POST['places'];
			$sector=$_POST['places'];
			$cell=$_POST['places'];
			 echo $w = "UPDATE researcher SET fname='$fname', pwd='$pwd',lname='$lname',email='$email',district='$district',province='$province',sector='$sector',cell='$cell',username='$username'
			 WHERE s_id=".$_POST['s_id'];
			 
			 $r = mysqli_query($conn,$w);
			 if(!$r){
				 echo "error ";
			 }else{
				 echo "Updated successfully";
			 }
			 
		 }
   }
?>

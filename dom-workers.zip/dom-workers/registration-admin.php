<?php

include_once 'dbconnection.php';

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$role=$_POST['role'];


if(empty($fname) || empty($lname) || empty($email) || empty($pwd)|| empty($role))
{
   header("Location:adimnsignup.php?error=empty");
   exit();
}
else
{
    if(!preg_match("/^[a-zA-Z]*$/",$fname) || !preg_match("/^[a-zA-Z]*$/",$lname))
    {
        header("Location:adminsignup.php?error=invalidNames");
        exit();
    }
    else
    {
           if(!filter_var($email,FILTER_VALIDATE_EMAIL))
           {
            header("Location:adminsignup.php?error=email");
            exit();
           }
           else
           {
            $sql="INSERT INTO admin(fname,lname,username,email,Pwd,role) VALUES('$fname','$lname','$uname','$email','$pwd','$role');";
            mysqli_query($conn,$sql);
            header("Location:as admin.php?error=success");
            exit();
           }
          
    }
}
?>
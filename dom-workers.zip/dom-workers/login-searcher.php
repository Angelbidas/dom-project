<?php
session_start();
include_once 'dbconnection.php';
$email=$_POST['email'];
$pwd=$_POST['pwd'];

if(empty($email) || empty($pwd))
{
    header("Location:assearcher.php?error=empty");
    exit();
}
else
{
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))
    {
        header("Location:assearcher.php?error=email");
        exit();
    }
    else
    {
       $sql="SELECT* FROM researcher WHERE email='$email';";
       $result=mysqli_query($conn,$sql);
       if(mysqli_num_rows($result)<1)
       {
          header("Location:assearcher.php?error=notFound");
          exit();
       }
       else
       {
           if($row=mysqli_fetch_assoc($result))
           {
               if($row['pwd']==$pwd)
               {

                $_SESSION['fname']=$row['fname'];
                header("Location:workeravailable.php");
                exit();
               }
           }
       }
    }
}
?>
-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 08:39 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `domestic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(30) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `Pwd` varchar(128) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `email`, `Pwd`, `fname`, `lname`, `id`, `role`) VALUES
('uwamahoro', 'murerwa@gmail.com', '1234', 'njenje', 'bebe', 1, NULL),
('uwamahoro', 'j.c.hakizimana2@ur.ac.rw', '1234', 'betty', 'mwiza', 2, NULL),
('uwamahoro', 'rosinegisubizo2@gmail.com', '', 'angelique', 'mwiza', 3, 'admin'),
('uwamahoro', 'rosinegisubizo2@gmail.com', '123', 'angelique', 'mwiza', 4, 'agent');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `names` varchar(50) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `names`, `email`, `phone`, `comments`) VALUES
(13, 'david yes', 'david@gmail.com', 789964535, 'hallelua'),
(14, 'ngarukiyimana sostene', 'murerwa@gmail.com', 780949596, 'hello'),
(15, 'ngarukiyimana sostene', 'rosinegisubizo2@gmail.com', 780949596, 'huhuu');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(11) NOT NULL,
  `fname` varchar(40) DEFAULT NULL,
  `lname` varchar(40) DEFAULT NULL,
  `email` varchar(140) DEFAULT NULL,
  `phone` varchar(140) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `fname`, `lname`, `email`, `phone`) VALUES
(3, 'angelique', 'mwiza', 'ngarukiyimanasostene@gmail.com', '0789653421'),
(4, 'angelique', 'mwiza', 'ngarukiyimanasostene@gmail.com', '0789653421'),
(5, 'angelique', 'mwiza', 'ngarukiyimanasostene@gmail.com', '0789653421'),
(15, 'angelique', 'mwiza', 'ngarukiyimanasostene@gmail.com', '0789653421'),
(16, 'angelique', 'mwiza', 'ngarukiyimanasostene@gmail.com', '0789653421'),
(17, 'angelique', 'ded', 'fredmugisha@gmail.com', '0789653421');

-- --------------------------------------------------------

--
-- Table structure for table `researcher`
--

CREATE TABLE `researcher` (
  `s_id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(128) NOT NULL,
  `pwd` text NOT NULL,
  `district` varchar(40) DEFAULT NULL,
  `province` varchar(40) DEFAULT NULL,
  `sector` varchar(40) DEFAULT NULL,
  `cell` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `researcher`
--

INSERT INTO `researcher` (`s_id`, `fname`, `lname`, `username`, `email`, `pwd`, `district`, `province`, `sector`, `cell`) VALUES
(17, 'angelique', 'mwiza', 'uwamahoro', 'rosinegisubizo2@gmail.com', '1234', 'huye', 'huye', 'huye', 'huye'),
(18, 'angelique', 'mwiza', 'uwamahoro', 'rosinegisubizo2@gmail.com', '1234', 'kigali', 'kigali', 'kigali', 'kigali'),
(19, 'angelique', 'mwiza', 'uwamahoro', 'rosinegisubizo2@gmail.com', '1234', 'kigali', 'kigali', 'kigali', 'kigali'),
(20, 'betty', 'mwiza', 'uwamahoro', 'murerwa@gmail.com', '1234', 'kimironko', 'kimironko', 'kimironko', 'kimironko');

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE `workers` (
  `w_id` int(11) NOT NULL,
  `fname` varchar(32) DEFAULT NULL,
  `lname` varchar(32) DEFAULT NULL,
  `worker_id` varchar(20) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `province` varchar(16) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `specification` varchar(32) DEFAULT NULL,
  `timeSlot` varchar(32) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `district` varchar(30) DEFAULT NULL,
  `sector` varchar(30) DEFAULT NULL,
  `cell` varchar(30) DEFAULT NULL,
  `pwd` varchar(128) DEFAULT NULL,
  `education` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`w_id`, `fname`, `lname`, `worker_id`, `email`, `province`, `phone`, `specification`, `timeSlot`, `gender`, `district`, `sector`, `cell`, `pwd`, `education`) VALUES
(6, 'angelique', 'bebe', '12345611111', 'ngarukiyimanasostene@gmail.com', 'kinynya', '0789653421', 'cleaning', 'month', 'male', 'kinynya', 'kinynya', 'kinynya', '1234', 'Secondary'),
(7, 'henry', 'jesus', '12345611111', 'fredmugisha@gmail.com', 'gasabo', '0789653421', 'cleaning', 'month', 'female', 'gasabo', 'gasabo', 'gasabo', '1234', 'Primary');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `researcher`
--
ALTER TABLE `researcher`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `workers`
--
ALTER TABLE `workers`
  ADD PRIMARY KEY (`w_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `researcher`
--
ALTER TABLE `researcher`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `workers`
--
ALTER TABLE `workers`
  MODIFY `w_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

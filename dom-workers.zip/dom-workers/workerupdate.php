<?php
   include("dbconnection.php");
   
   $r = "SELECT * FROM workers WHERE w_id =".$_GET['w_id'];
   
   $dx = mysqli_query($conn,$r);
   if(!$dx){
	   echo "Failed";
   }
   if($d = mysqli_fetch_array($dx)){
	   ?>
	   <form action="" method="post">
		  <input type="hidden" name ="w_id" value="<?php echo $d['w_id'];?>"/>
		  <br/>
        fname: <input type="text" name ="fname" value="<?php echo $d['fname'];?>"/>
		  <br/> 	
		  lname:<input type="text" name ="lname" value="<?php echo $d['lname'];?>"/>
		  <br/> 
		  username:<input type="text" name ="uname" value="<?php echo $d['username'];?>"/>
		  <br/> 
		  email:<input type="text" name ="email" value="<?php echo $d['email'];?>"/>
		  <br/>
			password:<input type="number" name ="password" value="<?php echo $d['pwd'];?>"/>
		   <br/> 
		   district:<input type="text" name ="places" value="<?php echo $d['district'];?>"/>
		  <br/> 
		  province:<input type="text" name ="places" value="<?php echo $d['province'];?>"/>
		  <br/> 
		  sector:<input type="text" name ="places" value="<?php echo $d['sector'];?>"/>
		  <br/> 
		  cell:<input type="text" name ="places" value="<?php echo $d['cell'];?>"/>
		  <br/> 
          phone:<input type="text" name ="tel" value="<?php echo $d['tel'];?>"/>
		  <br/> 
          unique:<input type="text" name ="specification" value="<?php echo $d['specification'];?>"/>
		  <br/> 
          timeslot:<input type="text" name ="time" value="<?php echo $d['time'];?>"/>
		  <br/> 
          education:<input type="text" name ="education" value="<?php echo $d['education'];?>"/>
		  <br/> 
          gender:<input type="text" name ="gender" value="<?php echo $d['gender'];?>"/>
		  <br/> 
			<input type="submit" name ="update" value="Update"/>
			<input type="submit" name ="retrieve" value="Retrieve"/>
		</form> 
	   
	   <?php  
	     if(isset($_POST['update'])){
			$fname=$_POST['fname'];
			$lname=$_POST['lname'];
			$username=$_POST['username'];
			$email=$_POST['email'];
			$pwd=$_POST['password'];
			$district=$_POST['places'];
			$province=$_POST['places'];
			$sector=$_POST['places'];
			$cell=$_POST['places'];
            $phone=$_POST['tel'];
            $unique=$_POST['specification'];
            $timeSlot=$_POST['time'];
            $education=$_POST['education'];
            if($_POST['gender']=="male")
            {
                 $gender="male";
                }
                else
                {
                    $gender="female";
                }
			 echo $w = "UPDATE workers SET fname='$fname', pwd='$pwd',username='$username',lname='$lname',email='$email',district='$district',province='$province',sector='$sector',cell='$cell',timeSlot='$timeSlot',phone='$phone',specification='$unique',education='$education',gender='$gender',
			 WHERE w_id=".$_POST['w_id'];
			 
			 $r = mysqli_query($conn,$w);
			 if(!$r){
				 echo "error ";
			 }else{
				 echo "Updated successfully";
			 }
			 
		 }
   }
?>
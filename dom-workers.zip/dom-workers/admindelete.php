<?php
  include("dbconnection.php");
  $id =$_GET['id'];
  
  $query = "DELETE FROM admin WHERE id=".$id;
  //echo $query;
  
  $r = mysqli_query($conn, $query);
  
  if($r){
	 header('location:admindetail.php');
  }else{
	  echo "Something went wrong!";
  }

?>
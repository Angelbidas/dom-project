<?php
$host="localhost";
$username="root";
$password="";
$dbName="domestic";
$conn=mysqli_connect($host,$username,$password,$dbName); 

?>
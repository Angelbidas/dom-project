
<?php
$conn=mysqli_connect('localhost','root','','domestic');
$result=mysqli_query($conn,"select * from workers");
?>
<html>
<head>
</head>
<script type="text/javascript">
function delete_s_id(s_id)
{
  var r=confirm("Press a button"); 
  if (r==true)
  {
 document.write("Are you sure you want to remove this record ?");
 else{
     window.location.href='delete.php?delete_s_id='+s_id;
 }
}
}
</script>

<body>

<header><center>
    <h2>workers available</h2>
</header></center>
  <article>  
<table style="width:50%;  margin-left: 0;px;"border=1;>
  <tr style="background-color:skyblue">
    <th>ID</th>
    <th>firstname</th>
    <th>lastname</th> 
    <th>worker_id</th>
    <th>email</th>
    <th>pwd</th>
    <th>phone</th>
    <th>specification</th>
    <th>timeslot</th>
    <th>gender</th>
    <th>province</th>
    <th>district</th>
    <th>sector</th>
    <th>cell</th>
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['w_id'];?></td>
    <td><?php echo $row['fname'];?></td>
    <td><?php echo $row['lname'];?></td>
    <td><?php echo $row['worker_id'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['pwd'];?></td>
    <td><?php echo $row['phone'];?></td>
    <td><?php echo $row['specification'];?></td>
    <td><?php echo $row['timeSlot'];?></td>
    <td><?php echo $row['gender'];?></td>
    <td><?php echo $row['province'];?></td>
    <td><?php echo $row['district'];?></td>
    <td><?php echo $row['sector'];?></td>
    <td><?php echo $row['cell'];?></td>
   
  
    <td><a href="request.php?w_id=<?php echo $row['w_id'];?>"> choose </a></td>


    <td>
    
                <form action="delete.php" method="post">
                  
                
                </form>
            </td>
  </tr>
  <?php endwhile;?>
</table>
 <p>designed by angel</p>
  </body>
  </html>

<?php

include_once 'dbconnection.php';

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$uname=$_POST['uname'];
$email=$_POST['email'];
$pwd=$_POST['password'];
$district=$_POST['places'];
$province=$_POST['places'];
$sector=$_POST['places'];
$cell=$_POST['places'];
if(empty($fname) || empty($lname) || empty($email) || empty($pwd)||empty($district)||empty($province)||empty($sector)||empty($cell))
{
   header("Location:ssignup.php?error=empty");
   exit();
}
else
{
    if(!preg_match("/^[a-zA-Z]*$/",$fname) || !preg_match("/^[a-zA-Z]*$/",$lname))
    {
        header("Location:ssignup.php?error=invalidNames");
        exit();
    }
    if(!preg_match("/^[a-zA-Z]*$/",$province) || !preg_match("/^[a-zA-Z]*$/",$district)|| !preg_match("/^[a-zA-Z]*$/",$sector)|| !preg_match("/^[a-zA-Z]*$/",$cell))
    {
        header("Location:ssignup.php?error=places");
        exit();
    }
    else
    {
           if(!filter_var($email,FILTER_VALIDATE_EMAIL))
           {
            header("Location:ssignup.php?error=email");
            exit();
           }
           else
           {
            $sql="INSERT INTO researcher(fname,lname,username,email,pwd,district,province,sector,cell) VALUES('$fname','$lname','$uname','$email','$pwd','$district','$province','$sector','$cell');";
            mysqli_query($conn,$sql);
            header("Location:assearcher.php?error=success");
            exit();
           }
          
    }
}
?>



<?php
$conn=mysqli_connect('localhost','root','','domestic');
$result=mysqli_query($conn,"select * from request");
?>
<html>
<head>

<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>dashbord</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link ref ="stylesheet" type="text/css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:200,300,400,500,600,700,800,900&display=swap');
*
{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}
body{
overflow-x:hidden;
}
.container{
position:relative;
width:100%;
}
.navigation{
position:fixed;
width: 280px;
height:100%;
background:#003147;
transition:0.5s;
overflow:hidden;
}
.navigation ul
{
position:absolute;
top:0;
left:0;
width:100%;
}
.navigation ul li
{
position:relative;
width:100%;
list-style: none;
}
.navigation ul li:hover
{
background:#03a9f4;
}
.navigation ul li:nth-child(1)
{
margin-bottom:20px;
}
.navigation ul li:nth-child(1):hover
{
background:transparent;
}
.navigation ul li a{
position:relative;
display:block;
width:100%;
display:flex;
text-decoration:none;
color:#fff;
}
.navigation ul li a .icon{
position:relative;
display:block;
min-width:60px;
height:60px;
line-height:60px;
text-align:center;
}
.navigation ul li a .icon .fa
{
color:#fff;
font-size:24px;
}

</style>
</head>
<script type="text/javascript">
function delete_id(id)
{
 if(confirm('Are you sure you want to remove this record ?'))
 {
  window.location.href='delete.php?delete_id='+id;
 }
}
</script>




<body>

<div class="container">
<div class="navigation"> 
<ul>
<li>
<a href="#">
<span class="icon"><i class="fa fa-tachometer" aria-hidden="true"></i></span>
<span class="title"><h2>dashboard</h2></span>
</a>
</li>
<li>
<a href="dashboard.php?page=searcherdetail">
<span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
<span class="title"><h2>searcher</h2></span>
</a>
</li>
<li>
<a href="dashboard.php?page=workerdetail">
<span class="icon"><i class="fa fa-briefcase" aria-hidden="true"></i></span>
<span class="title"><h2>worker</h2></span>
</a>
</li>
<li>

<a href="dashboard.php?page=messages">
<span class="icon"><i class="fa fa-comment" aria-hidden="true"></i></span>
<span class="title"><h2>message</h2></span>
</a>
</li>
<li>
<a href="dashboard.php?page=admindetail">
<span class="icon"><i class="fa fa-user-o" aria-hidden="true"></i></span>
<span class="title"><h2>admin</h2></span>
</a>
</li>
<li>

<a href="dashboard.php?page=reqadmin">
<span class="icon"><i class="fa fa-question-circle" aria-hidden="true"></i></span>
<span class="title"><h2>request</h2></span>
</a>
</li>
<li>
<a href="#">
<span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
<span class="title"><h2>settings</h2></span>
</a>
</li>
<li>

<a href="as admin.php">
<span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
<span class="title"><h2>sign out</h2></span>
</a>
</li>
</ul>
</div>
</div>

<header><center>
    <h2>people request</h2>
</header></center>
  <article>  
  <table style="width:60%;  margin-left:280px;"border=1;>
  <tr style="background-color:skyblue ">
    <th>ID</th>
    <th>firstname</th>
    <th>lastname</th> 
    <th>email</th>
    <th>phone</th>
  
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['id'];?></td>
    <td><?php echo $row['fname'];?></td>
    <td><?php echo $row['lname'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['phone'];?></td>
   
   
  
  
    
    <td>
    
                <form action="delete.php" method="post">
                  
                
                </form>
            </td>
  </tr>
  <?php endwhile;?>
</table>
 <p>designed by angel</p>
  </body>
  </html>

<?php

include_once 'dbconnection.php';

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$pwd=$_POST['password'];
$ID=$_POST['mail'];
$email=$_POST['id'];
$district=$_POST['places'];
$province=$_POST['places'];
$sector=$_POST['places'];
$cell=$_POST['places'];
$phone=$_POST['tel'];
$unique=$_POST['specification'];
$time=$_POST['time'];
$education=$_POST['education'];
if($_POST['gender']=="male")
{
    $gender="male";
}
else
{
    $gender="female";
}

if(empty($fname) || empty($lname) || empty($ID) || empty($email) || empty($province) || empty($phone) || empty($unique) || empty($time) || empty($education) || empty($gender) || empty($district) || empty($sector)|| empty($cell)|| empty($pwd))
{
   header("Location:workerregister.php?error=empty");
   exit();
}
else
{
    if(!preg_match("/^[a-zA-Z]*$/",$fname) || !preg_match("/^[a-zA-Z]*$/",$lname))
    {
        header("Location:workerregister.php?error=invalidNames");
        exit();
    }
    else
    {
       if(!preg_match("/^[0-9]*$/",$ID)) 
       {
        header("Location:workerregister.php?error=w_id");
        exit();
       }
       else
       {
           if(!filter_var($email,FILTER_VALIDATE_EMAIL))
           {
            header("Location:workerregister.php?error=email");
            exit();
           }
           else
           {
            if(!preg_match("/^[a-zA-Z]*$/",$district)||!preg_match("/^[a-zA-Z]*$/",$province)||!preg_match("/^[a-zA-Z]*$/",$sector)||!preg_match("/^[a-zA-Z]*$/",$cell))
            {
                header("Location:workerregister.php?error=invalidplaces");
                exit(); 
            }
            else
            {
                if(!preg_match("/^[0-9]{10,12}$/",$phone))
                {
                    header("Location:workerregister.php?error=phone");
                    exit();
                }
                else
                {
                    if(!preg_match("/^[a-zA-Z ]*$/",$unique))
                    {
                        header("Location:workerregister.php?error=specific");
                        exit();
                    }
                    else
                    {
                        if(!preg_match("/^[a-zA-Z0-9 ]*$/",$time))
                        {
                        header("Location:workerregister.php?error=time");
                        exit();
                        }
                        else
                        {
                            if(!preg_match("/^[a-zA-Z]*$/",$education))
                             {
                                header("Location:workerregister.php?error=education");
                                 exit(); 
                             }
                             else
                             {
                                 $sql="INSERT INTO workers(fname,lname,worker_id,email,phone,specification,timeSlot,pwd,province,district,sector,cell,education,gender) VALUES('$fname','$lname','$ID','$email','$phone','$unique','$time','$pwd','$province','$district','$sector','$cell','$education','$gender');";
                                 mysqli_query($conn,$sql);
                                 header("Location:as worker.php");
                                 exit();
                             }
                        }
                    }
                }
            }
           }
       }
    }
}
?>
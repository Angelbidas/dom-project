<?php
  include("dbconnection.php");
  $id =$_GET['id'];
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $uname=$_POST['uname'];
  $email=$_POST['email'];
  $pwd=$_POST['password'];
  $district=$_POST['places'];
  $province=$_POST['places'];
  $sector=$_POST['places'];
  $cell=$_POST['places'];
  $query = "UPDATE researcher SETfname='$fname', lname='$lname',username='$lname',email='$email',district='$district',province='$province',sector='$sector',cell='$cell'
  WHERE id=".$_POST['id'];
  //echo $query;
  
  $r = mysqli_query($conn, $query);
  
  if($r){
	 header('location:searcherdetail.php');
  }else{
	  echo "Something went wrong!";
  }

?>



<?php
$conn=mysqli_connect('localhost','root','','domestic');
$result=mysqli_query($conn,"select * from request");
?>
<html>
<head>


</head>
<script type="text/javascript">
function delete_id(id)
{
 if(confirm('Are you sure you want to remove this record ?'))
 {
  window.location.href='delete.php?delete_id='+id;
 }
}
</script>




<body>



<header><center>
    <h2>people request</h2>
</header></center>
  <article>  
  <table style="width:60%;  margin-left:280px;"border=1;>
  <tr style="background-color:skyblue ">
    <th>ID</th>
    <th>firstname</th>
    <th>lastname</th> 
    <th>email</th>
    <th>phone</th>
  
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['id'];?></td>
    <td><?php echo $row['fname'];?></td>
    <td><?php echo $row['lname'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['phone'];?></td>
   
   
  
   <td><a href="request.php?id=<?php echo $row['id'];?>"> choose</a> </td>
  
    
    <td>
    
                <form action="delete.php" method="post">
                  
                
                </form>
            </td>
  </tr>
  <?php endwhile;?>
</table>
 <p>designed by angel</p>
  </body>
  </html>

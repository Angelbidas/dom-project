
<?php
$conn=mysqli_connect('localhost','root','','domestic');
$result=mysqli_query($conn,"select * from researcher");
?>
<html>
<head>




<body>
<header><center>
    <h2>searcher details</h2>
</header></center>
  <article>  
<table style="width:100%;  margin-left:0px;"border=1;>
  <tr style="background-color:skyblue ">
    <th>ID</th>
    <th>firstname</th>
    <th>lastname</th> 
    <th>username</th>
    <th>email</th>
    <th>pwd</th>
    <th>province</th>
    <th>district</th>
    <th>sector</th>
    <th>cell</th>
   
  </tr>
  <?php while($row=mysqli_fetch_array($result)):?>
  <tr>
    <td><?php echo $row['s_id'];?></td>
    <td><?php echo $row['fname'];?></td>
    <td><?php echo $row['lname'];?></td>
    <td><?php echo $row['username'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['pwd'];?></td>
    <td><?php echo $row['province'];?></td>
    <td><?php echo $row['district'];?></td>
    <td><?php echo $row['sector'];?></td>
    <td><?php echo $row['cell'];?></td>
    <td>
    
  
  </td>
    <td>
                <form action="delete.php" method="post">
                  <input type="hidden" name="delete_s_id" value="<?php echo $row['s_id']; ?>">
                  
                  <td><a href="request.php?s_id=<?php echo $row['s_id'];?>"> choose </a></td>
                </form>
            </td>
                  
            
                </form>
            </td>
  </tr>
  <?php endwhile;?>
</table>
 <p>designed by angel</p>
 
  </body>
  </html>

<html>
<head>
<title>home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   
</head>
<style>
.topnav{
margin: top 100px;
background-color:#333;
height:80px;
}
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align:right;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
.dropbtn{
  display:inline-block;
color:white;
text-align:right;
padding:14px 16px;
text-decoration:none;
}
.dropbtn {
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* The container needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}
/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: skyblue}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}


.topnav a:hover, .dropdown:hover .dropbtn{
background-color:skyblue;
}
ul {
 list-style-type: none;
 margin: 0;
 padding: 0;
 overflow: hidden;
 background-color: #333333;
}
li a {
 display: block;
 color: white;
 text-align: center;
 padding: 16px;
 text-decoration: none;
}
.column {
  float: left;
  width: 33.33%;
  padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
.main {
  padding: 20px;
  margin-top: 20px;
  height: 500px; 
}
.topnav-right {
  float: right;
}

img:hover {
  -webkit-transform: scaleX(-1);
  transform: scaleX(-1);
}
* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  font-size: 17px;
}

.container {
  position: relative;
  max-width: 800px;
  margin: 0 auto;
}

.container img {vertical-align: middle;}

.container .content {
  position: absolute;
  bottom: 0;
  background: rgb(0, 0, 0); 
  background: rgba(0, 0, 0, 0.5); 
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
}
.fa {
  padding: 30px;
  font-size: 30px;
  width: 30px;
  text-align: left;
  text-decoration: none;
  margin: 2px 2px;
  border-radius: 50%;
}

.fa:hover {
    opacity: 0.4;
}



@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@700&display=swap');

body{
line-height:1.5;
font-family: 'Poppins', sans-serif;
}
*
{
margin:0;
padding:0;
box-sizing:border-box;
}
.row .column{
float:left;
width:33.33%;
border: rgba(0, 0, 0, 0.5);
}
.row:after
{
content:"";
display:table;
clear:both;
}
.footer ul{

display:flex;
flex-direction:column;
}
.footer ul li{
text-align:left;
}
.footer{
background-color:#24262b;
padding:70px 0;
}
.footer-col{
width:25%;
padding:0 15px;
}
.footer-col h4{
color:#ffffff;
text-transform:capitalize;
margin-bottom:35px;
font-weight:500;
position:relative;

}
.footer-col h4::before{
content:'';
position:absolute;
left:0;
bottom:-10px;
background-color:#e91e63;
height:2px;
box-sizing:border-box;
width:50px;
}
.column ul li:not(:last-child){
margin-bottom:10px;
}
.footer a{
font-size:16px;
text-transform:capitalize;
color:#ffffff;
text-decoration:none;
font-weight:300;
color:#bbbbbb;
transition:all 0.3s ease;
}
.footer a:hover{
color:#ffffff;
padding-left:8px;
}
.footer .social-links a{
height:40px;
width:40px;
background-color:rgba(255,255,255,0.2);
text-align:center;
line-height:40%;
border-radius:50%;
color:#ffffff;
transition:all 0.5s ease;
margin-right: 20px;
}
.column .social-links a:hover{
color:#24262b;
background-color:#ffffff;
}
@media(ma-width:767px)
{
.footer-col{
width:50%;
margin-bottom:30px;
}
}
h4{ text-align:center;
font-size:24px;
color:black;
font-weight:bold;
font-family:serif;

}
.footer-text p
{
  color: rgba(255, 255, 255, 0.438);
  
}
body{
margin:0;
padding:0;
 background-image:url(dom-photos/ind.jpg);
 background-size:cover;
 background-position:center;
 font-family:sans-serif;
 }

</style>
</head>
<body>

<div class="topnav">

<a href="index.php">HOME</a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="contactus.php">CONTACT US</a>
 
<a href="aboutus.php">ABOUT US</a>
 
  <div class="dropdown">
 <a href="#"class="dropbtn">LOGIN</a>
 <div class="dropdown-content">
  <a href="assearcher.php">AS SEARCHER</a>
  <a href="as worker.php">AS WORKER</a>
  <a href="as admin.php">AS ADMIN</a>
   </div>
</div>
</div>
<br/>

<h1 align="center"> GET DOMESTIC WORKERS ONLINE</h1>
 <h1 align="center"> AND ASSURED VERIFIED</h1></br></br></br></br></br>
<div class="row">
<div class="column">
</div>
  <div class="column"><center>
<h2 align="center">Who are domestic workers?</h2>
<h3 align="center">Domestic workers are those workers who perform work in or for a private household or households.
 They provide direct and indirect care services, and as such are key members of the care economy.</p></h3>
 </center></div></div>
 <p align="right">
<div class="main">
</div>

<div class="footer">
<div class="row">
<div class="column">
<ul>
<li><h4>ABOUT </h4></li>
<li><a href="aboutus.html">aboutus</a></li>
<li><a href="https://en.wikipedia.org/wiki/Domestic_worker">history</a></li>
<li><a href="workerregister.html">resources </a></li>
<li><a href="requirement.html">requirement</a></li>
</ul>
</div>
<div class="column">
<ul>
<li><h4>GET HELP</h4></li>
<li><a href="workerregister.html">registration</a></li>
<li><a href="contactus.html">contactus</a></li>
<li><a href="ssignup.html">account</a></li>
<li><a href="aboutus.html">aboutus</a></li>
</ul>
</div>
<div class="column">
<ul>
<li><h4>GET INVOLVED</h4></li>
<li><a href="worker signup.html">signup</a></li>
<li><a href="requirement.html">requirement</a></li>
<li><a href="assearcher.html">search</a></li>
<li><a href="as worker.html">worker</a></li>
</ul>
</div>
</div><center>
<div class="social-links">
<a href="https://twitter.com/domesticworkers"><i class="fab fa-twitter"></i></a>
<a href="https://www.facebook.com/nationaldomesticworkersalliance/"><i class="fab fa-facebook-f"></i></a>
<a href="https://www.instagram.com/domesticworkers/"><i class="fab fa-instagram"></i></a>
</center>
<div class="footer-text-container">
  <div class="footer-text">

  <p class="small show-for-en">©2021 Copyright National Domestic Workers Alliance, A non-profit organization whose mission is to support domestic workers to live and work with dignity. <a href="/privacy-policy" target="_blank">Privacy Policy</a></p>
  </div>
  </div>
</div>
</div>
</footer>
</div>
</div>
</body>
</html>

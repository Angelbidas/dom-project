<head>
<style>

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>
</head>
<body onload="myFunction()" style="margin:0;">


<div style="display:none;" id="myDiv" class="animate-bottom">
  <h2>thanks!</h2>
  <p>your request has been submitted successfully..</p>
</div>
<?php
header( "refresh:4;url=request.php" ); ?>
<script>
var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 1000);
}

function showPage() {;
  document.getElementById("myDiv").style.display = "block";
}
</script>

</body>



<?php

include_once 'dbconnection.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    if(isset($_POST['submit']))
    {
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['id'];
$phone=$_POST['tel'];

if(empty($fname) || empty($lname)  || empty($email) )
{
   header("Location:request.php?error=empty");
   exit();
}
else
{
    if(!preg_match("/^[a-zA-Z]*$/",$fname) || !preg_match("/^[a-zA-Z]*$/",$lname))
    {
        header("Location:request.php?error=invalidNames");
        exit();
    }
   
       else
       {
           if(!filter_var($email,FILTER_VALIDATE_EMAIL))
           {
            header("Location:request.php?error=email");
            exit();
            header( "refresh:1;url=index.php" );
           }
           
            else
            {
                if(!preg_match("/^[0-9]{10,12}$/",$phone))
                {
                    header("Location:request.php?error=phone");
                    exit();
                }
               
                   
                        
                    
                            
                             else
                             {
                                 $sql="INSERT INTO request(fname,lname,email,phone) VALUES('$fname','$lname','$email','$phone');";
                                 mysqli_query($conn,$sql);
                                 header("Location:reg-request.php");
                                 exit();
                             }
                        
                    
                
            }
           }
       }
    }
}
    
?>
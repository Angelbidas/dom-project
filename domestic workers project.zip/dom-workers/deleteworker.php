<?php
  include("dbconnection.php");
  $w_id =$_GET['w_id'];
  
  $query = "DELETE FROM workers WHERE w_id=".$w_id;
  //echo $query;
  
  $r = mysqli_query($conn, $query);
  
  if($r){
	 header('location:workerdetail.php');
  }else{
	  echo "Something went wrong!";
  }

?>
<?php
session_start();
include_once 'dbconnection.php';
$email=$_POST['email'];
$pwd=$_POST['pwd'];

if(empty($email) || empty($pwd))
{
    header("Location:as admin.php?error=empty");
    exit();
}
else
{
    if(!filter_var($email,FILTER_VALIDATE_EMAIL))
    {
        header("Location:as admin.php?error=email");
        exit();
    }
    else
    {
       $sql="SELECT* FROM admin WHERE email='$email';";
       $result=mysqli_query($conn,$sql);
       if(mysqli_num_rows($result)<1)
       {
          header("Location:as admin.php?error=notFound");
          exit();
       }
    

                $_SESSION['fname']=$row['fname'];
                header("Location:dashboard.php?error=success");
                exit();
               }
           }
       
    

?>